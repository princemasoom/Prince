# bxi
Termux new commands for facebook
# Super Multi Brute force
# Cloning facebook IDs
# Facebook Public Info collecting

# Install

$apt update && apt upgrade

$apt install python2

$apt install git

$git clone https://github.com/binyamin-binni/bxi

# Use

$cd bxi

$python2 bxi.py

Now it'll ask to you 'have you already binni's tools account' if you don't have then put n or no and press enter.

After that it will redirect you to your browser and open the registration page.

you have to create your account there and then come back to terminal and now reply with yes or y.

Put your email and password that you used to create account for Binni's Tools.

That's it '.

Now it will open the main section of tool. Login with facebook and enjoy your day.
